package Day0616;

public class PrintfTest_06 {

	public static void main(String[] args) {
		// printf로 출력하세요
		// 안녕하세요 제 이름은 송혜교입니다.
		// 나이는 25세입니다.
		// %d: 정수
		// %f: 실수
		// %s: 문자열
		// %c: 문자(char)
		
		String name="원빈";
		int age=25;

		System.out.printf("안녕하세요 제 이름은 %s입니다. \n나이는 %d입니다.",name,age);
		
	}

}
