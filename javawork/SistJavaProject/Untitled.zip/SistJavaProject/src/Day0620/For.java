package Day0620;

public class For {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//for(초기값;조건식;증감식);
		for(int i=0;i<3;i++)
		{
			System.out.println(i);
		
			//초기 -> 조건 -> 프린트 -> 증감 -> 조건 -> 프린트 -> 증감 -> 조건 -> 프린트.... 순서로 진행된다. 조건이 끝날때까지..
			
		//while(조건)
			
			
		}
		
	}

}



			