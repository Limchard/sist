package Day0615;

public class Book29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		int x;
//		x=1;
// '='은 오른쪽 값을 왼쪽에 대입 할꺼야
// '==' 이게 equal 의미야		
		
		int x=5;
		int y=63;
		
		int result=x+y;
		System.out.println("x와 y의 합은 "+result +" 이다");
		
		
		
		
	}

}
