package Day0615;

public class ArgsTest_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//실행할때 매개변수를 보내서 출력하세요
		/* 안녕~ 내이름은 유재석이고 나의 직업은 개그맨이야*/
		
		System.out.println("안녕~ 내 이름은 "+args[0]+"이고 나의 직업은 "+args[1]+"이야");
		
	}

}

