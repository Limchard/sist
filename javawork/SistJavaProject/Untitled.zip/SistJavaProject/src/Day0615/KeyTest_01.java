// 위에 파일명에 * 표시는 저장이 안되었다는 표시이다.

package Day0615;

public class KeyTest_01 {

	public static void main(String[] args) {

		
		// ctrl+i : 자동들여쓰기
		// ctrl+shift+L : 단축키 전체목록 보기
		// ctrl+ +/- 로 폰트크기 증가/감소
		// ctrl+s : 저장
		
		System.out.println("이제부터는 이클립스로 작업!!!!");
		System.out.println("이제부터는 이클립스로 작업!!!!");

		System.out.println("이제부터는 이클립스로 작업!!!!");


		System.out.println("이제부터는 이클립스로 작업!!!!");
		System.out.println("이제부터는 이클립스로 작업!!!!");

		System.out.println("이제부터는 이클립스로 작업!!!!");

		System.out.println("이제부터는 이클립스로 작업!!!!");
		System.out.println("이제부터는 이클립스로 작업!!!!");

		System.out.println("이제부터는 이클립스로 작업!!!!");

	}

}

