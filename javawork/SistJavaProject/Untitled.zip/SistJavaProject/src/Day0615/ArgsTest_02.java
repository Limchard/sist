package Day0615;

public class ArgsTest_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("**mian 매개변수 테스트**");
		System.out.println("첫번째 값: "+args[0]);
		System.out.println("두번째 값: "+args[1]);
		System.out.println(args[0]+args[1]);
		
	}

}
