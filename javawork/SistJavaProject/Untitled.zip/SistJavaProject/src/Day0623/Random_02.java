package Day0623;

import java.util.Random;

public class Random_02 {

	public static void main(String[] args) {
		// Random 클래스
		
		Random rd=new Random();
		
		System.out.println("0~9사이의 난수를 발생시켜 보자.");
		for(int i=1;i<=3;i++) {
			int n=rd.nextInt(10);
			System.out.println(n);
		}
		
		System.out.println("1~10사이의 난수를 발생시켜 보자.");
		for(int i=1;i<=3;i++) {
			int n=rd.nextInt(10)+1;
			System.out.println(n);
		}

	}

}


// null값 들어갔어? == 값이 안들어갔어?
// 숫자가 없다 == 0, 문자가 없다 == null 